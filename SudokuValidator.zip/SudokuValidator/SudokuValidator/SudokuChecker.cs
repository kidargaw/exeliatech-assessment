﻿using System;
namespace SudokuValidator
{
    public class SudokuChecker
    {
        private int[][] values;
        public SudokuChecker(int[][] val)
        {
            values = val;
        }
        public async Task<bool> isValidSudoku()
        {
            if (!hasValidBox())
            {
                return false;
            }

            IEnumerable<bool> result = await Task.WhenAll<bool>(
                                    hasValidRows(values),
                                    hasValidCols(values));

            if (result.Any(r => r == false))
                return false;
            return true;
        }
        public async Task<bool> hasValidRows(int[][] values)
        {
            return await Task.Run<bool>(() =>
            {
                foreach (int[] row in values)
                {
                    if (hasInvalidValues(row))
                    {
                        return false;
                    }
                    if (isNotSameAndUnique(row))
                    {
                        return false;
                    }
                }
                return true;
            });
        }
        public async Task<bool> hasValidCols(int[][] values)
        {
            var length = values.Length;

            return await Task.Run<bool>(() =>
            {
                for (int colIndex = 0; colIndex < length; colIndex++)
                {
                    int[] column = Enumerable.Range(0, length)
                            .Select(x => values[x][colIndex])
                            .ToArray();
                    if (hasInvalidValues(column))
                    {
                        return false;
                    }
                    if (isNotSameAndUnique(column))
                    {
                        return false;
                    }
                }
                return true;
            });
        }
        public bool isNotSameAndUnique(int[] item)
        {
            HashSet<int> uniqueVals = new HashSet<int>(item);
            return item.Length != uniqueVals.Count;
        }
        public bool hasValidBox()
        {
            var rowLength = values.GetLength(0);
            if (rowLength < 1)
                return false;
            //checking row length == col length and col is a perfecte square
            return (rowLength == values[0].Length) && Math.Sqrt(rowLength) % 1 == 0;
        }
        public bool hasInvalidValues(int[] vals) => vals.Any(i => i < 1 && i > vals.Length);
    }
}

