declare let window: any;
export class DynamicEnvironment{
    public get environment(){
        return window.config.enviroment;
    }
    public get baseURL(){
        return window.config.baseURL;
    }
    public get apiKey(){
        return window.config.apiKey;
    }
}