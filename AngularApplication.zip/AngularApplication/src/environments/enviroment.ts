import { DynamicEnvironment } from "./DynamicEnvironment";


class Environment {
    public production: boolean;
    public baseURL: string = "http://www.omdbapi.com/?"
    public apiKey: string = "db091133";
    public userId: string = "tt3896198"
    constructor(){
        this.production = false;
    }
}
export const environment = new Environment();