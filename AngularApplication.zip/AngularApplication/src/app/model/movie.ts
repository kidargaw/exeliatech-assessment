export interface Movie {
    imdbID: string;
    Title: string;
    Poster: string;
    Year: number;
    Type: string;
}