import { Movie } from "./movie";

export type ApiResponse = {
    Response: string;
    Search: Movie[];
    totalResults: string;
  };