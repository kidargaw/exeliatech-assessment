import { Component, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Movie } from '../model/movie';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent {
  @ViewChild("searchInput") searchInput: ElementRef;
  hasMinLen: boolean = false;
  title = 'exelia-app';
  isDark = true;
  AllMovies: Movie[] = [];
  
  constructor(private service: MovieService, private router: Router) {
    this.service.getMoviesById('tt4244162').subscribe((data) =>{
      console.log(data);
      
    })
  }
  keyup($event: KeyboardEvent, searchValue: string) {
    this.hasMinLen = searchValue.length >= 3;
    if(this.hasMinLen){
      this.service.getMoviesByTitle(searchValue).subscribe((data) => {
        console.log(data);
        this.AllMovies = data.Search.slice(0, 3);
      })
    }
  }
  clearSearch() {
    this.searchInput.nativeElement.value = "";
    this.hasMinLen = false;
  }
  showDetail(id: string){
    this.router.navigate([`/detail/${id}`]);
    // console.log("geting data");
    // this.service.getMoviesById(id).subscribe((data) =>{
    //   console.log(data);
    //   this.router.navigate(['/detail']);
    // })
    // this.service.getMoviesById(id).subscribe((data) =>{
    //   console.log(data);
    //   console.log("replay data");
      
    //   //
    // })
  }
}
