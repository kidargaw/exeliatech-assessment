import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { ApiResponse } from './model/ApiResponse';
import { MovidDetail } from './model/MovieDetail';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  API: string = '';
  constructor(private httpClient: HttpClient, @Inject('env') api: any)
  {
    this.API = `${api.baseURL}apiKey=${api.apiKey}`;
  }
  getMoviesByTitle(title: string){
    return this.httpClient
    .get<ApiResponse>(`${this.API}&s=${title}`)
    .pipe((data) => {
      return data
    });
  }
  
  getMoviesById(id: string): Observable<MovidDetail>{
    return this.httpClient
    .get<MovidDetail>(`${this.API}&i=${id}`)
    .pipe((data) => {
      return data
    });
  }
}
