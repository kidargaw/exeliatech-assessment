import { Component, ElementRef, ViewChild } from '@angular/core';
import { Movie } from './model/movie';
import { MovieCardComponent } from './movie-card/movie-card.component';
import { MovieService } from './movie.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // @ViewChild("searchInput") searchInput: ElementRef;
  // hasMinLen: boolean = false;
  // title = 'exelia-app';
  // isDark = true;
  // AllMovies: Movie[] = [];
  
  // constructor(private service: MovieService) {
  // }
  // keyup($event: KeyboardEvent, searchValue: string) {
  //   this.hasMinLen = searchValue.length >= 3;
  //   if(this.hasMinLen){
  //     this.service.getMoviesByTitle(searchValue).subscribe((data) => {
  //       console.log(data);
  //       this.AllMovies = data.Search.slice(0, 3);
  //     })
  //   }
  // }
  // clearSearch() {
  //   this.searchInput.nativeElement.value = "";
  //   this.hasMinLen = false;
  // }
  // showDetail(id: string){
  //   this.service.getMoviesById(id).subscribe((data) =>{
  //     console.log(data);
      
  //   })
  // }
}
