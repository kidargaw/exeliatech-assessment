import { Component, Input } from '@angular/core';
import { ActivatedRoute, Route } from '@angular/router';
import { MovidDetail } from '../model/MovieDetail';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-movie-detail',
  templateUrl: './movie-detail.component.html',
  styleUrls: ['./movie-detail.component.css'],
})
export class MovieDetailComponent {
  movieDetail: MovidDetail;
  movieId: string;
  constructor(
    private service: MovieService,
    private activeRoute: ActivatedRoute
  ) {
    this.movieId = this.activeRoute.snapshot.params['MovieId'];
    this.service.getMoviesById(this.movieId).subscribe((data) => {
      console.log(data);
      this.movieDetail = data;
    });
  }
}
