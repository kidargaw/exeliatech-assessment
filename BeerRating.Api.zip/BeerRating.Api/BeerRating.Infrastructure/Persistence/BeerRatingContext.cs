﻿using System;
using System.Reflection;
using BeerRating.Application.Core.Contract;
using BeerRating.Domain.BaseEntities;
using BeerRating.Domain.Entities;
using Microsoft.EntityFrameworkCore;


namespace BeerRating.Infrastructure.Persistence
{
    public class BeerRatingContext : DbContext, IBeerRatingDbContext
    {
        public const string Schema = "BeerRating";
        public BeerRatingContext(DbContextOptions options) : base(options)
        {
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
            AppContext.SetSwitch("Npgsql.DisableDateTimeInfinityConversions", true);
        }
        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            ValidateEntitiesOnSaving();
            return base.SaveChangesAsync(cancellationToken);
        }
        public override int SaveChanges()
        {
            ValidateEntitiesOnSaving();
            return base.SaveChanges();
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema(Schema);
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
        private void ValidateEntitiesOnSaving()
        {
            foreach (var entity in ChangeTracker.Entries<AuditEntity>())
            {
                switch (entity.State)
                {
                    case EntityState.Added:
                        entity.Entity.CreatedOn = DateTimeOffset.UtcNow.DateTime;
                        entity.Entity.IsDeleted = false;
                        break;
                    case EntityState.Deleted:
                        entity.Entity.DeletedOn = DateTimeOffset.UtcNow.DateTime;
                        entity.Entity.IsDeleted = true;
                        break;
                }
            }
        }
        public DbSet<Beer> Beers { get; set; }
        public DbSet<BeerRate> BeerRates { get; set; }
    }
}