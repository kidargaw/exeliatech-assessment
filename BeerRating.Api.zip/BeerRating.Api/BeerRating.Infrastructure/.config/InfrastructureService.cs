﻿using BeerRating.Application.Core.Contract;
using BeerRating.Infrastructure.Persistence;
using BeerRating.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BeerRating.Infrastructure.config
{
    public static class InfrastructureService
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services,
            IConfiguration configuration)
        {
            var provider = "PostgresSQL";
            var connectionString = configuration.GetConnectionString("PSQL");
            services.AddDbContext<BeerRatingContext>(
                options => _ = provider switch
                {
                    "PostgresSQL" => options.UseNpgsql(
                        connectionString: connectionString,
                        npgsqlOptionsAction => npgsqlOptionsAction.MigrationsAssembly(typeof(BeerRatingContext).Assembly.FullName))
                });
            services.AddScoped(typeof(IRepository<>), typeof(BaseRepository<>));
            services.AddScoped<IBeerRepository, BeerRepository>();
            return services;
        }
    }
}

