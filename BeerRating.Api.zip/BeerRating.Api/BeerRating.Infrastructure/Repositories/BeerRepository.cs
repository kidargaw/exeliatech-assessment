﻿using System;
using System.Linq.Expressions;
using BeerRating.Application.Core.Contract;
using BeerRating.Domain.Entities;
using BeerRating.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace BeerRating.Infrastructure.Repositories
{
    public class BeerRepository : BaseRepository<Beer>, IBeerRepository
    {
        protected readonly BeerRatingContext _dbContext;
        public BeerRepository(BeerRatingContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IReadOnlyList<BeerRate>> GetAllBeerRateAsync(Guid beerId)
        {
            return await _dbContext.BeerRates
                    .Where(b => b.BeerId == beerId && !b.IsDeleted)
                    .ToListAsync();
        }

        public async Task<IReadOnlyList<Beer>> GetAllBeersWithRateAsync()
        {
            return await _dbContext.Beers
                .Include(b => b.Ratings)
                .Where(b => !b.IsDeleted)
                .ToListAsync();
        }

        public async Task<IReadOnlyList<Beer>> SearchBeersByNameAsync(string name)
        {
            char[] chars = name.ToCharArray().Distinct().ToArray();

            var result = await _dbContext.Beers
                            .Include(b => b.Ratings)
                            .Where(b => !b.IsDeleted)
                            .ToListAsync();
            return result.Where(b => b.Name.IndexOfAny(chars) != -1).ToList();
        }
    }
}

