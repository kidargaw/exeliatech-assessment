﻿using System;
using BeerRating.Application.Core.Contract;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using BeerRating.Infrastructure.Persistence;

namespace BeerRating.Infrastructure.Repositories
{
    public class BaseRepository<T> : IRepository<T> where T : Domain.BaseEntities.Entity<Guid>
    {
        protected readonly BeerRatingContext _dbContext;

        public BaseRepository(BeerRatingContext vtsDbContext)
        {
            _dbContext = vtsDbContext;
        }

        public async Task<T> AddAsync(T entity, CancellationToken cancellation)
        {
            await _dbContext.Set<T>().AddAsync(entity, cancellation);
            await _dbContext.SaveChangesAsync(cancellation);
            return entity;
        }

        public async Task<T> GetByIdAsync(Guid Id)
        {
            return await _dbContext.Set<T>().FirstOrDefaultAsync(e => e.Id == Id && !e.IsDeleted);
        }

        public async Task<IReadOnlyList<T>> ListAllAsync()
        {
            return await _dbContext.Set<T>().Where(e => !e.IsDeleted).ToListAsync();
        }

        public async Task<T> UpdateAsync(T entity)
        {
            _dbContext.Entry(entity).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<IReadOnlyList<T>> GetPagedResponseAsync(int page, int size)
        {
            return await _dbContext.Set<T>().Where(e => !e.IsDeleted).Skip((page - 1) * size).Take(size).AsNoTracking()
                .ToListAsync();
        }

        public Task<int> CountAsync()
        {
            return _dbContext.Set<T>().Where(e => !e.IsDeleted).CountAsync();
        }

        public Task<int> SearchCountAsync(Expression<Func<T, bool>> expression)
        {
            return _dbContext.Set<T>().Where(expression).CountAsync();
        }
    }
}

