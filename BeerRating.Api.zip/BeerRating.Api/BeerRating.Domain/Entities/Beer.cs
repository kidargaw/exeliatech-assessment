﻿using System;
using BeerRating.Domain.BaseEntities;

namespace BeerRating.Domain.Entities;

public class Beer : Entity<Guid>
{
    public string Name { get; set; }
    public int BeerType { get; set; }
    public virtual ICollection<BeerRate> Ratings { get; set; }
}