﻿using System;
using BeerRating.Domain.BaseEntities;

namespace BeerRating.Domain.Entities;
public class BeerRate : Entity<Guid>
{
    public Guid BeerId { get; set; }
    public int RatePoint { get; set; }
}