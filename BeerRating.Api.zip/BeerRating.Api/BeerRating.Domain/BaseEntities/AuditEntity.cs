﻿using System;
namespace BeerRating.Domain.BaseEntities
{
    public class AuditEntity
    {
        public DateTimeOffset CreatedOn { get; set; }
        public DateTimeOffset? DeletedOn { get; set; }
        public bool IsDeleted { get; set; }
    }
}

