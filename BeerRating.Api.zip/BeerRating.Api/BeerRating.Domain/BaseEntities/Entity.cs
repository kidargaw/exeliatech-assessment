﻿using System;
namespace BeerRating.Domain.BaseEntities
{
    public class Entity<TKey> : AuditEntity
    {
        public TKey Id { get; set; }
    }
}

