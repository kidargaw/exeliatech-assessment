﻿using System;
using System.ComponentModel;

namespace BeerRating.Application.Core.Enum
{
    public enum BeerType
    {
        [Description("Pale Ale")] PaleAle = 1,
        [Description("Stout")] Stout
    }
}

