﻿using System;
using AutoMapper;
using BeerRating.Application.Business.Beer.Command.Create;
using BeerRating.Application.Business.Beer.Query.GetBeers;
using BeerRating.Application.Business.BeerRate.Command.Create;
using BeerRating.Application.Core.Enum;
using BeerRating.Domain.Entities;

namespace BeerRating.Application.Core
{
    internal class BeerRatingMapping : Profile
    {
        public BeerRatingMapping()
        {
            CreateMap<Beer, CreateBeerResponse>()
                .ForMember(dest => dest.BeerTypeDescription,
                    opt => opt.MapFrom(src => System.Enum.GetName((BeerType)src.BeerType)))
                .ForMember(dest => dest.Rate, opt => opt.MapFrom(src => AvgRate(src)))
                .ReverseMap();

            CreateMap<BeerRate, CreateBeerRateResponse>()
                .ForMember(dest => dest.BeerId, opt => opt.MapFrom(src => src.BeerId))
                .ForMember(dest => dest.RatePoint, opt => opt.MapFrom(src => src.RatePoint))
                .ReverseMap();

            CreateMap<Beer, GetBeersResponse>()
                .ForMember(dest => dest.BeerType, opt => opt.MapFrom(src => ((BeerType)src.BeerType).ToString()))
                .ForMember(dest => dest.NumberOfRate, opt => opt.MapFrom(src => src.Ratings.Count()))
                .ForMember(dest => dest.AverageRate, opt => opt.MapFrom(src => src.Ratings.Any() ? Math.Round(src.Ratings.Average(b => b.RatePoint), 2) : 0.0))
                .ReverseMap();
        }

        private static double? AvgRate(Beer src) => src.Ratings?.Average(i => i.RatePoint);

    }
}