﻿using System;
using System.Linq.Expressions;

namespace BeerRating.Application.Core.Contract
{
    public interface IRepository<T> where T : class
    {
        public Task<T> GetByIdAsync(Guid Id);

        Task<IReadOnlyList<T>> ListAllAsync();

        Task<T> AddAsync(T entity, CancellationToken cancellationToken);

        Task<T> UpdateAsync(T entity);

        Task<IReadOnlyList<T>> GetPagedResponseAsync(int page, int size);

        Task<int> CountAsync();

        Task<int> SearchCountAsync(Expression<Func<T, bool>> expression);
    }
}

