﻿using BeerRating.Domain.Entities;

namespace BeerRating.Application.Core.Contract
{
    public interface IBeerRepository : IRepository<Beer>
    {
        Task<IReadOnlyList<Beer>> SearchBeersByNameAsync(string name);
        Task<IReadOnlyList<Beer>> GetAllBeersWithRateAsync();
        Task<IReadOnlyList<BeerRate>> GetAllBeerRateAsync(Guid beerId);
    }
}

