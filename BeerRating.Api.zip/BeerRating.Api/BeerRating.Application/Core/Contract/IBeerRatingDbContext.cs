﻿using BeerRating.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace BeerRating.Application.Core.Contract
{
    public interface IBeerRatingDbContext
    {
        DbSet<Beer> Beers { get; }
        DbSet<BeerRate> BeerRates { get; }
    }
}