﻿using AutoMapper;
using BeerRating.Application.Core.Contract;
using MediatR;

namespace BeerRating.Application.Business.Beer.Command.Create
{
    public class CreateBeerCommandHandler : IRequestHandler<CreateBeerCommand, CreateBeerResponse>
    {
        private readonly IMapper _mapper;
        private readonly IBeerRepository _repository;
        public CreateBeerCommandHandler(IMapper mapper, IBeerRepository repository)
        {
            _mapper = mapper;
            _repository = repository;
        }

        public async Task<CreateBeerResponse> Handle(CreateBeerCommand request, CancellationToken cancellationToken)
        {
            var createBeerResponse = new CreateBeerResponse();

            var validator = new CreateBeerValidator(await _repository.ListAllAsync());
            var validationResult = await validator.ValidateAsync(request, cancellationToken);

            if (validationResult.Errors.Count > 0)
            {
                createBeerResponse.Success = false;
                createBeerResponse.ValidationErrors = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    createBeerResponse.ValidationErrors.Add(error.ErrorMessage);
                }
                return createBeerResponse;
            }
            var newBeer = new Domain.Entities.Beer
            {
                Name = request.Name,
                BeerType = request.BeerType
            };
            var beer = await _repository.AddAsync(newBeer, cancellationToken);
            return _mapper.Map<CreateBeerResponse>(beer);
        }
    }
}

