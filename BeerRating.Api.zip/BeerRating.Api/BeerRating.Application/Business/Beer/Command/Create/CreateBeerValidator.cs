﻿using System;
using System.Numerics;
using BeerRating.Application.Core.Enum;
using FluentValidation;

namespace BeerRating.Application.Business.Beer.Command.Create
{
    public class CreateBeerValidator : AbstractValidator<CreateBeerCommand>
    {
        private readonly IEnumerable<Domain.Entities.Beer> _beers;
        public CreateBeerValidator(IEnumerable<Domain.Entities.Beer> beers)
        {
            _beers = beers;

            RuleFor(p => p.Name)
               .NotEmpty().WithMessage("{PropertyName} is required")
               .NotNull().WithMessage("{PropertyName} is required")
               .Must(IsNameUnique).WithMessage("{PropertyName} must be unique.");

            RuleFor(p => p.BeerType)
                .NotEmpty().WithMessage("{PropertyName} is required")
                .NotNull().WithMessage("{PropertyName} is required")
                .Must(BeerTypeExist).WithMessage("{PropertyName} doesnot exist.");
        }
        public bool IsNameUnique(CreateBeerCommand beer, string name)
        {
            return !_beers.Any(b => b.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase));
        }
        public bool BeerTypeExist(CreateBeerCommand beer, int beerType)
        {
            return Enum.IsDefined(typeof(BeerType), beerType);
        }
    }
}

