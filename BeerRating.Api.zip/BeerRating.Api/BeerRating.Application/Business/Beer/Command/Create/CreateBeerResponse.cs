﻿using System;
using BeerRating.Application.Core;

namespace BeerRating.Application.Business.Beer.Command.Create
{
    public class CreateBeerResponse : BaseResponse
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string BeerTypeDescription { get; set; }
        public double? Rate { get; set; }
    }
}

