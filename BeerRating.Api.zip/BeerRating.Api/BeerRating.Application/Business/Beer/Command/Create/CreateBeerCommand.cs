﻿using System.ComponentModel.DataAnnotations;
using MediatR;

namespace BeerRating.Application.Business.Beer.Command.Create
{
    public class CreateBeerCommand : IRequest<CreateBeerResponse>
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public int BeerType { get; set; }
    }
}

