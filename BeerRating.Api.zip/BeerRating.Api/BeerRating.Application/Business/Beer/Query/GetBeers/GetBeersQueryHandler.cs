﻿using System;
using AutoMapper;
using BeerRating.Application.Core;
using BeerRating.Application.Core.Contract;
using MediatR;

namespace BeerRating.Application.Business.Beer.Query.GetBeers
{
    public class GetBeersQueryHandler : IRequestHandler<GetBeersQuery, Pagination<GetBeersResponse>>
    {
        private readonly IBeerRepository _beersRepo;
        private readonly IMapper _mapper;
        public GetBeersQueryHandler(IBeerRepository beersRepo, IMapper mapper)
        {
            _beersRepo = beersRepo;
            _mapper = mapper;
        }

        public async Task<Pagination<GetBeersResponse>> Handle(GetBeersQuery request, CancellationToken cancellationToken)
        {
            var validator = new GetBeerQueryValidator();
            var validationResult = await validator.ValidateAsync(request, cancellationToken);

            if (!validationResult.IsValid)
            {
                return new Pagination<GetBeersResponse>(request.PageIndex, request.PageSize, 0, null, false,
                    validationResult.Errors.Select(e => e.ErrorMessage).ToList());
            }

            var totalItems = await _beersRepo.CountAsync();

            var beers = await _beersRepo.SearchBeersByNameAsync(request.BeerName);

            var data = _mapper.Map<List<GetBeersResponse>>(beers);

            return new Pagination<GetBeersResponse>(request.PageIndex,
                request.PageSize, totalItems, data, true, new List<string>());
        }
    }
}

