﻿using System;
using FluentValidation;

namespace BeerRating.Application.Business.Beer.Query.GetBeers
{
    public class GetBeerQueryValidator : AbstractValidator<GetBeersQuery>
    {
        public GetBeerQueryValidator()
        {
            RuleFor(p => p.BeerName)
               .NotEmpty().WithMessage("{PropertyName} is required")
               .NotNull().WithMessage("{PropertyName} is required");

            RuleFor(p => p.PageSize).LessThan(50).GreaterThan(0)
                .WithMessage("{PageSize} must be greater than 0 and maximum 50 size");
        }
    }
}

