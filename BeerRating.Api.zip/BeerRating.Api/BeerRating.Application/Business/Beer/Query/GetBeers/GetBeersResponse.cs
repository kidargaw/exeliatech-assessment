﻿using System;
using BeerRating.Application.Core;

namespace BeerRating.Application.Business.Beer.Query.GetBeers
{
    public class GetBeersResponse : BaseResponse
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string BeerType { get; set; }
        public int NumberOfRate { get; set; }
        public double AverageRate { get; set; }
    }
}

