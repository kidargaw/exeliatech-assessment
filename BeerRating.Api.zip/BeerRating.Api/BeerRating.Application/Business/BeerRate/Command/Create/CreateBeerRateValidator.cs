﻿using System;
using System.Numerics;
using FluentValidation;

namespace BeerRating.Application.Business.BeerRate.Command.Create
{
    public class CreateBeerRateValidator : AbstractValidator<CreateBeerRateCommand>
    {
        private readonly Domain.Entities.Beer? _beer;
        public CreateBeerRateValidator(Domain.Entities.Beer? beers)
        {
            this._beer = beers;
            RuleFor(p => p.BeerId)
               .NotEmpty().WithMessage("{PropertyName} is required")
               .NotNull().WithMessage("{PropertyName} is required");

            RuleFor(p => p.RatePoint)
                .NotEmpty().WithMessage("{PropertyName} is required")
                .NotNull().WithMessage("{PropertyName} is required")
                .GreaterThan(0).WithMessage("{PropertyName} is must be greater than 0")
                .LessThanOrEqualTo(5).WithMessage("{PropertyName} is must be less than 5");

            RuleFor(p => p.BeerId).Must(ValiedBeerId)
                .WithMessage("{PropertyName} doesnot exist.");
        }
        public bool ValiedBeerId(CreateBeerRateCommand beerRateCommand, Guid beerId)
        {
            if (_beer == null)
                return false;

            return _beer.Id == beerId;
        }
    }
}

