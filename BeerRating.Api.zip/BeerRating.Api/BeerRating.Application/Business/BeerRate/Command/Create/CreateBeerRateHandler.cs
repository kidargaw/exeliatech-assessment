﻿using AutoMapper;
using BeerRating.Application.Core.Contract;
using MediatR;
using BeerRating.Domain.Entities;

namespace BeerRating.Application.Business.BeerRate.Command.Create
{
    public class CreateBeerRateHandler : IRequestHandler<CreateBeerRateCommand, CreateBeerRateResponse>
    {
        private readonly IMapper _mapper;
        private readonly IRepository<Domain.Entities.BeerRate> _repository;
        private readonly IRepository<Domain.Entities.Beer> _beerRepository;

        public CreateBeerRateHandler(IMapper mapper, IRepository<Domain.Entities.BeerRate> repository, IRepository<Domain.Entities.Beer> beerRepository)
        {
            _mapper = mapper;
            _repository = repository;
            _beerRepository = beerRepository;
        }



        public async Task<CreateBeerRateResponse> Handle(CreateBeerRateCommand request, CancellationToken cancellationToken)
        {
            var createBeerResponse = new CreateBeerRateResponse();

            var validator = new CreateBeerRateValidator(await _beerRepository.GetByIdAsync(request.BeerId));
            var validationResult = await validator.ValidateAsync(request, cancellationToken);

            if (validationResult.Errors.Count > 0)
            {
                createBeerResponse.Success = false;
                createBeerResponse.ValidationErrors = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    createBeerResponse.ValidationErrors.Add(error.ErrorMessage);
                }
                return createBeerResponse;
            }
            var newBeerRate = new Domain.Entities.BeerRate
            {
                BeerId = request.BeerId,
                RatePoint = request.RatePoint
            };
            var beerRate = await _repository.AddAsync(newBeerRate, cancellationToken);

            return _mapper.Map<CreateBeerRateResponse>(beerRate);
        }
    }
}

