﻿using System.ComponentModel.DataAnnotations;
using MediatR;

namespace BeerRating.Application.Business.BeerRate.Command.Create
{
    public class CreateBeerRateCommand : IRequest<CreateBeerRateResponse>
    {
        [Required]
        public Guid BeerId { get; set; }
        [Required]
        [Range(0, 5, ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int RatePoint { get; set; }
    }
}

