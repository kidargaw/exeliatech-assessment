﻿using System;
using BeerRating.Application.Core;

namespace BeerRating.Application.Business.BeerRate.Command.Create
{
    public class CreateBeerRateResponse : BaseResponse
    {
        public Guid Id { get; set; }
        public Guid BeerId { get; set; }
        public int RatePoint { get; set; }
        public DateTimeOffset CreatedOn { get; set; }
    }
}

