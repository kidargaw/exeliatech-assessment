﻿using System;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace BeerRating.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public abstract class ApiControllerBase : ControllerBase
    {
        private ISender _mediator = null!;

        protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();
        protected IActionResult Result<TData>(TData data) => data != null ? Ok(data) : NotFound();

    }
}

