﻿using System;
using AutoMapper;
using BeerRating.Application.Business.Beer.Command.Create;
using BeerRating.Application.Business.Beer.Query.GetBeers;
using BeerRating.Application.Business.BeerRate.Command.Create;
using BeerRating.Application.Core;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace BeerRating.Api.Controllers
{
    public class BeerController : ApiControllerBase
    {
        private readonly IMediator mediator;
        private readonly IMapper mapper;
        private ILogger<BeerController> logger;
        public BeerController(IMediator mediator, IMapper mapper, ILogger<BeerController> logger)
        {
            this.mediator = mediator;
            this.mapper = mapper;
            this.logger = logger;
        }
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateBeer([FromBody] CreateBeerCommand request, CancellationToken cancellationToken)
        {
            var result = await mediator.Send(request, cancellationToken);
            return result is null ? (IActionResult)NoContent() : Ok(result);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> RateBeer([FromBody] CreateBeerRateCommand request, CancellationToken cancellationToken)
        {
            var result = await mediator.Send(request, cancellationToken);
            return result is null ? (IActionResult)NoContent() : Ok(result);
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<Pagination<GetBeersResponse>>> GetBeers(
            [FromQuery] GetBeersQuery beersQuery)
        {
            var result = await mediator.Send(beersQuery);
            return result is null ? NoContent() : Ok(result);
        }

    }
}
